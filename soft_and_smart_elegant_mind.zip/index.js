
    import React from 'react';
    import ReactDOM from 'react-dom';
    import ElegantMind from './ElegantMind';

    ReactDOM.render(
      <React.StrictMode>
        <ElegantMind />
      </React.StrictMode>,
      document.getElementById('root')
    );
    