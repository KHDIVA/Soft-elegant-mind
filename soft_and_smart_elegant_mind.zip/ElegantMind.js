
    import { Card, CardContent } from "@/components/ui/card";
    import { Button } from "@/components/ui/button";
    import { BookOpen, Sparkles, MessageCircle } from "lucide-react";

    export default function ElegantMind() {
      return (
        <div className="p-6 max-w-4xl mx-auto grid gap-6 bg-sky-100 min-h-screen text-gray-800">
          <h1 className="text-4xl font-bold text-center text-purple-700">The Soft and Smart Elegant Mind</h1>
          <p className="text-center text-lg mb-4">
            A refined space for mastering elevated English and cultivating elegant communication.
          </p>

          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="text-purple-500" />
                <h2 className="text-2xl font-semibold">Word of the Day</h2>
              </div>
              <p><strong>Word:</strong> Poised</p>
              <p><strong>Meaning:</strong> Calm, graceful, and in control under pressure.</p>
              <p><strong>Example:</strong> "She remained poised during the interview, even when the questions were challenging."</p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <MessageCircle className="text-purple-500" />
                <h2 className="text-2xl font-semibold">Affirmation of the Day</h2>
              </div>
              <p>"I express myself with clarity, calm, and elegance."</p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="text-purple-500" />
                <h2 className="text-2xl font-semibold">Practice Sentence</h2>
              </div>
              <p>"Even when the room was chaotic, she remained <strong>poised</strong> and spoke with grace."</p>
            </CardContent>
          </Card>

          <div className="text-center">
            <Button className="bg-purple-500 hover:bg-purple-600 text-white">Start Daily Quiz</Button>
          </div>
        </div>
      );
    }
    